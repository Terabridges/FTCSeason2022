/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    right_driveAsDcMotor.setDirection("REVERSE");
    while (linearOpMode.opModeIsActive()) {
      left_driveAsDcMotor.setPower(1);
      right_driveAsDcMotor.setPower(1);
      linearOpMode.sleep(1000);
      left_driveAsDcMotor.setPower(0);
      right_driveAsDcMotor.setPower(0);
      linearOpMode.sleep(1000);
      telemetry.update();
    }
  }
}
