/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  // You will have to determine which motor to reverse for your robot.
  // In this example, the right motor was reversed so that positive
  // applied power makes it move the robot in the forward direction.
  right_driveAsDcMotor.setDirection("REVERSE");
  left_driveAsDcMotor.setMode("RUN_WITHOUT_ENCODER");
  right_driveAsDcMotor.setMode("RUN_WITHOUT_ENCODER");
  left_shooterAsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      // The Y axis of a joystick ranges from -1 in its topmost position
      // to +1 in its bottommost position. We negate this value so that
      // the topmost position corresponds to maximum forward power.
      left_driveAsDcMotor.setDualPower(0.75 * (gamepad1.getLeftStickY() - gamepad1.getLeftStickX()), right_driveAsDcMotor, 0.75 * (gamepad1.getLeftStickY() + gamepad1.getLeftStickX()));
      left_shooterAsDcMotor.setPower(-0.9 * gamepad1.getRightTrigger());
      intakeAsDcMotor.setPower(1 * gamepad1.getLeftTrigger());
      if (gamepad1.getLeftBumper()) {
        ConveyerAsDcMotor.setPower(0);
      } else if (gamepad1.getRightBumper()) {
        ConveyerAsDcMotor.setPower(-0.8);
      }
      if (gamepad1.getDpadLeft()) {
        ArmAsDcMotor.setPower(-1);
      } else if (gamepad1.getDpadRight()) {
        ArmAsDcMotor.setPower(0.5);
      } else if (gamepad1.getDpadUp()) {
        ArmAsDcMotor.setPower(0);
      }
      if (gamepad1.getA()) {
        GripperAsServo.setPosition(-1);
      } else if (gamepad1.getY()) {
        GripperAsServo.setPosition(1);
      } else if (gamepad1.getB()) {
        GripperAsServo.setPosition(0.5);
      }
      telemetry.addNumericData('Left Drive Pow', left_driveAsDcMotor.getPower());
      telemetry.addNumericData('Right Drive Pow', right_driveAsDcMotor.getPower());
      telemetry.addNumericData('Left Shot Pow', left_shooterAsDcMotor.getPower());
      telemetry.addNumericData('Servo Pos', GripperAsServo.getPosition());
      telemetry.update();
    }
  }
}
