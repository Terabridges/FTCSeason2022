var i, recognition, recognitions, index;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  telemetryAddTextData('Test', 'Start');
  dbgLogAccess.msg('ALL CAPS stazrting log');
  telemetry.update();
  vuforiaCurrentGameAccess.initialize_withWebcam("Webcam 1", '', false, false, "AXES", 0, 0, 0, 0, 0, 0, true);
  dbgLogAccess.error('ALL CAPS errors on Vf');
  telemetryAddTextData('Test', 'Past Vuforia');
  telemetry.update();
  tfodCurrentGameAccess.initialize(vuforiaCurrentGameAccess, 0.7, true, true);
  // Init TFOD here so the object detection labels are visible
  // in the Camera Stream preview window on the Driver Station.
  tfodCurrentGameAccess.activate();
  tfodCurrentGameAccess.setZoom(1.5, 16 / 9);
  telemetryAddTextData('>', 'Press Play to start');
  left_driveAsDcMotor.setMode("RUN_WITHOUT_ENCODER");
  left_driveAsDcMotor.setMode("RUN_WITHOUT_ENCODER");
  telemetry.update();
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      // Get a list of recognitions from TFOD.
      recognitions = JSON.parse(tfodCurrentGameAccess.getRecognitions());
      // If list is empty, inform the user. Otherwise, go
      // through list and display info for each recognition.
      if (recognitions.length == 0) {
        telemetryAddTextData('TFOD', 'No items detected.');
        telemetryAddTextData('Target Zone', 'A');
        left_driveAsDcMotor.setDualPower(-0.75, right_driveAsDcMotor, 0.75);
        linearOpMode.sleep(500);
        left_driveAsDcMotor.setDualPower(-1, right_driveAsDcMotor, 0.25);
        linearOpMode.sleep(800);
        left_driveAsDcMotor.setDualPower(-1, right_driveAsDcMotor, 0);
        linearOpMode.sleep(600);
        left_driveAsDcMotor.setDualPower(0, right_driveAsDcMotor, 0);
        ArmAsDcMotor.setPower(0.75);
        linearOpMode.sleep(950);
        ArmAsDcMotor.setPower(0);
        linearOpMode.sleep(200);
        GripperAsServo.setPosition(1);
        linearOpMode.sleep(800);
        left_driveAsDcMotor.setDualPower(-0.25, right_driveAsDcMotor, -0.75);
        linearOpMode.sleep(1200);
        left_driveAsDcMotor.setDualPower(-0.75, right_driveAsDcMotor, -0.25);
        linearOpMode.sleep(700);
        left_driveAsDcMotor.setDualPower(0, right_driveAsDcMotor, 0);
        left_shooterAsDcMotor.setPower(0.7);
        linearOpMode.sleep(2000);
        ConveyerAsDcMotor.setPower(-0.6);
        linearOpMode.sleep(400);
        intakeAsDcMotor.setPower(1);
        linearOpMode.sleep(2000);
        left_shooterAsDcMotor.setPower(0);
        ConveyerAsDcMotor.setDualPower(0, intakeAsDcMotor, 0);
        linearOpMode.sleep(200);
        left_driveAsDcMotor.setDualPower(-1, right_driveAsDcMotor, 0.4);
        linearOpMode.sleep(1100);
        left_driveAsDcMotor.setDualPower(0, right_driveAsDcMotor, 0);
        linearOpMode.sleep(200);
        GripperAsServo.setPosition(0.5);
        linearOpMode.sleep(600);
        ArmAsDcMotor.setPower(-0.75);
        linearOpMode.sleep(900);
        ArmAsDcMotor.setPower(0);
        linearOpMode.sleep(200);
        left_driveAsDcMotor.setDualPower(0.25, right_driveAsDcMotor, -0.25);
        linearOpMode.sleep(400);
        left_driveAsDcMotor.setDualPower(-0.25, right_driveAsDcMotor, -0.75);
        linearOpMode.sleep(1200);
        left_driveAsDcMotor.setDualPower(-0.75, right_driveAsDcMotor, -0.25);
        linearOpMode.sleep(1300);
        left_driveAsDcMotor.setDualPower(-0.75, right_driveAsDcMotor, 0.75);
        linearOpMode.sleep(800);
        left_driveAsDcMotor.setDualPower(0, right_driveAsDcMotor, 0);
        linearOpMode.sleep(600);
        ArmAsDcMotor.setPower(0.75);
        linearOpMode.sleep(900);
        ArmAsDcMotor.setPower(0);
        linearOpMode.sleep(200);
        GripperAsServo.setPosition(1);
        linearOpMode.sleep(30000);
      } else {
        index = 0;
        // Iterate through list and call a function to
        // display info for each recognized object.
        for (var recognition_index in recognitions) {
          recognition = recognitions[recognition_index];
          displayInfo(index);
          index = index + 1;
        }
      }
      telemetry.update();
    }
  }
  tfodCurrentGameAccess.deactivate();
}

/**
 * Display info (using telemetry) for a recognized object.
 */
function displayInfo(i) {
  // Display the label and index number for the recognition.
  telemetryAddTextData('label ' + String(i), recognition.Label);
  // Display the location of the top left corner
  // of the detection boundary for the recognition
  telemetryAddTextData('Left, Top ' + String(i), String(recognition.Left) + String(', ' + String(recognition.Top)));
  // Display the location of the bottom right corner
  // of the detection boundary for the recognition
  telemetryAddTextData('Right, Bottom ' + String(i), String(recognition.Right) + String(', ' + String(recognition.Bottom)));
  if (recognition.Label == 'Single') {
    telemetryAddTextData('Target Zone', 'B');
    left_driveAsDcMotor.setDualPower(-0.7, right_driveAsDcMotor, 0.8);
    linearOpMode.sleep(400);
    left_driveAsDcMotor.setDualPower(0, right_driveAsDcMotor, 0);
    intakeAsDcMotor.setPower(1);
    linearOpMode.sleep(400);
    left_driveAsDcMotor.setDualPower(-0.6, right_driveAsDcMotor, 0.4);
    linearOpMode.sleep(400);
    left_driveAsDcMotor.setDualPower(-0.75, right_driveAsDcMotor, 0.75);
    linearOpMode.sleep(1400);
    intakeAsDcMotor.setPower(0);
    left_driveAsDcMotor.setDualPower(0, right_driveAsDcMotor, 0);
    ArmAsDcMotor.setPower(0.75);
    linearOpMode.sleep(1000);
    ArmAsDcMotor.setPower(0);
    linearOpMode.sleep(500);
    GripperAsServo.setPosition(1);
    linearOpMode.sleep(200);
    left_driveAsDcMotor.setDualPower(0.25, right_driveAsDcMotor, -0.25);
    linearOpMode.sleep(400);
    left_driveAsDcMotor.setDualPower(-0.25, right_driveAsDcMotor, -0.75);
    linearOpMode.sleep(1200);
    left_driveAsDcMotor.setDualPower(-1, right_driveAsDcMotor, -0.25);
    linearOpMode.sleep(1200);
    left_driveAsDcMotor.setDualPower(-0.75, right_driveAsDcMotor, 0.75);
    linearOpMode.sleep(1100);
    left_driveAsDcMotor.setDualPower(0, right_driveAsDcMotor, 0);
    linearOpMode.sleep(200);
    GripperAsServo.setPosition(0.5);
    linearOpMode.sleep(600);
    ArmAsDcMotor.setPower(-0.75);
    linearOpMode.sleep(900);
    ArmAsDcMotor.setPower(0);
    linearOpMode.sleep(200);
    left_driveAsDcMotor.setDualPower(1, right_driveAsDcMotor, -0.6);
    linearOpMode.sleep(300);
    left_driveAsDcMotor.setDualPower(0, right_driveAsDcMotor, 0);
    linearOpMode.sleep(100);
    left_shooterAsDcMotor.setPower(0.7);
    linearOpMode.sleep(2000);
    ConveyerAsDcMotor.setPower(-0.6);
    linearOpMode.sleep(400);
    intakeAsDcMotor.setPower(1);
    linearOpMode.sleep(2000);
    left_shooterAsDcMotor.setPower(0);
    ConveyerAsDcMotor.setDualPower(0, intakeAsDcMotor, 0);
    linearOpMode.sleep(200);
    left_driveAsDcMotor.setDualPower(1, right_driveAsDcMotor, 0.25);
    linearOpMode.sleep(700);
    left_driveAsDcMotor.setDualPower(0.25, right_driveAsDcMotor, 0.75);
    linearOpMode.sleep(900);
    left_driveAsDcMotor.setDualPower(-0.5, right_driveAsDcMotor, 0.5);
    linearOpMode.sleep(400);
    left_driveAsDcMotor.setDualPower(0, right_driveAsDcMotor, 0);
    linearOpMode.sleep(200);
    ArmAsDcMotor.setPower(0.75);
    linearOpMode.sleep(900);
    ArmAsDcMotor.setPower(0);
    linearOpMode.sleep(500);
    GripperAsServo.setPosition(1);
    linearOpMode.sleep(30000);
  } else if (recognition.Label == 'Quad') {
    telemetryAddTextData('Target Zone', 'C');
    left_driveAsDcMotor.setDualPower(-1, right_driveAsDcMotor, 0.25);
    linearOpMode.sleep(700);
    left_driveAsDcMotor.setDualPower(-0.25, right_driveAsDcMotor, 1);
    linearOpMode.sleep(600);
    left_driveAsDcMotor.setDualPower(-1, right_driveAsDcMotor, 0.8);
    linearOpMode.sleep(1400);
    left_driveAsDcMotor.setDualPower(0, right_driveAsDcMotor, 0);
    ArmAsDcMotor.setPower(0.75);
    linearOpMode.sleep(1000);
    ArmAsDcMotor.setPower(0);
    linearOpMode.sleep(500);
    GripperAsServo.setPosition(1);
    linearOpMode.sleep(500);
    left_driveAsDcMotor.setDualPower(0.25, right_driveAsDcMotor, -0.25);
    linearOpMode.sleep(800);
    left_driveAsDcMotor.setDualPower(-0.25, right_driveAsDcMotor, -0.75);
    linearOpMode.sleep(1200);
    left_driveAsDcMotor.setDualPower(-1, right_driveAsDcMotor, -0.25);
    linearOpMode.sleep(900);
    left_driveAsDcMotor.setDualPower(-0.75, right_driveAsDcMotor, 0.75);
    linearOpMode.sleep(800);
    left_driveAsDcMotor.setDualPower(0.75, right_driveAsDcMotor, 0.25);
    linearOpMode.sleep(100);
    left_driveAsDcMotor.setDualPower(0, right_driveAsDcMotor, 0);
    linearOpMode.sleep(200);
    left_shooterAsDcMotor.setPower(0.8);
    linearOpMode.sleep(2000);
    ConveyerAsDcMotor.setPower(-0.6);
    linearOpMode.sleep(400);
    intakeAsDcMotor.setPower(1);
    linearOpMode.sleep(2000);
    left_shooterAsDcMotor.setPower(0);
    ConveyerAsDcMotor.setDualPower(0, intakeAsDcMotor, 0);
    linearOpMode.sleep(200);
    left_driveAsDcMotor.setDualPower(0.5, right_driveAsDcMotor, -0.5);
    linearOpMode.sleep(400);
    left_driveAsDcMotor.setDualPower(0, right_driveAsDcMotor, 0);
    linearOpMode.sleep(30000);
  } else {
    telemetryAddTextData('Target Zone', 'UNKNOWN');
  }
}
