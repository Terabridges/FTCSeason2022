/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    GripperAsServo.setPosition(0);
    linearOpMode.sleep(1000);
    GripperAsServo.setPosition(0.5);
    linearOpMode.sleep(1000);
    GripperAsServo.setPosition(1);
    linearOpMode.sleep(1000);
  }
}
