var StartTime;

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  right_shooterAsDcMotor.setDirection("REVERSE");
  right_shooterAsDcMotor.setMode("STOP_AND_RESET_ENCODER");
  right_shooterAsDcMotor.setDualTargetPosition(1000, left_shooterAsDcMotor, 2000);
  right_shooterAsDcMotor.setMode("RUN_TO_POSITION");
  right_shooterAsDcMotor.setDualTargetPosition(1000, left_shooterAsDcMotor, 2000);
  linearOpMode.waitForStart();
  right_shooterAsDcMotor.setDualPower(0.5, right_shooterAsDcMotor, 0.5);
  StartTime = linearOpMode.getRuntime();
  while (linearOpMode.opModeIsActive() && linearOpMode.getRuntime() - StartTime < 1.5) {
    telemetry.update();
  }
  right_shooterAsDcMotor.setDualPower(0, right_shooterAsDcMotor, 0);
}
