package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.RobotLog;
import java.util.List;
import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaCurrentGame;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaLocalizer;
import org.firstinspires.ftc.robotcore.external.tfod.Recognition;
import org.firstinspires.ftc.robotcore.external.tfod.TfodCurrentGame;

@Autonomous(name = "TFODWebcam (Blocks to Java)", preselectTeleOp = "MainProgram")
public class TFODWebcam extends LinearOpMode {

  private VuforiaCurrentGame vuforiaUltimateGoal;
  private TfodCurrentGame tfodUltimateGoal;
  private DcMotor left_drive;
  private DcMotor right_drive;
  private DcMotor Arm;
  private Servo Gripper;
  private DcMotor left_shooter;
  private DcMotor Conveyer;
  private DcMotor intake;

  Recognition recognition;

  /**
   * This function is executed when this Op Mode is selected from the Driver Station.
   */
  @Override
  public void runOpMode() {
    List<Recognition> recognitions;
    double index;

    vuforiaUltimateGoal = new VuforiaCurrentGame();
    tfodUltimateGoal = new TfodCurrentGame();
    left_drive = hardwareMap.get(DcMotor.class, "left_drive");
    right_drive = hardwareMap.get(DcMotor.class, "right_drive");
    Arm = hardwareMap.get(DcMotor.class, "Arm");
    Gripper = hardwareMap.get(Servo.class, "Gripper");
    left_shooter = hardwareMap.get(DcMotor.class, "left_shooter");
    Conveyer = hardwareMap.get(DcMotor.class, "Conveyer");
    intake = hardwareMap.get(DcMotor.class, "intake");

    // Sample TFOD Op Mode
    // Initialize Vuforia.
    telemetry.addData("Test", "Start");
    RobotLog.ii("DbgLog", "ALL CAPS stazrting log");
    telemetry.update();
    vuforiaUltimateGoal.initialize(
        "", // vuforiaLicenseKey
        hardwareMap.get(WebcamName.class, "Webcam 1"), // cameraName
        "", // webcamCalibrationFilename
        false, // useExtendedTracking
        false, // enableCameraMonitoring
        VuforiaLocalizer.Parameters.CameraMonitorFeedback.AXES, // cameraMonitorFeedback
        0, // dx
        0, // dy
        0, // dz
        0, // xAngle
        0, // yAngle
        0, // zAngle
        true); // useCompetitionFieldTargetLocations
    RobotLog.ee("DbgLog", "ALL CAPS errors on Vf");
    // Set min confidence threshold to 0.7
    telemetry.addData("Test", "Past Vuforia");
    telemetry.update();
    tfodUltimateGoal.initialize(vuforiaUltimateGoal, 0.7F, true, true);
    // Initialize TFOD before waitForStart.
    // Init TFOD here so the object detection labels are visible
    // in the Camera Stream preview window on the Driver Station.
    tfodUltimateGoal.activate();
    // Enable following block to zoom in on target.
    tfodUltimateGoal.setZoom(1.5, 16 / 9);
    telemetry.addData(">", "Press Play to start");
    telemetry.update();
    // Wait for start command from Driver Station.
    waitForStart();
    if (opModeIsActive()) {
      // Put run blocks here.
      while (opModeIsActive()) {
        // Put loop blocks here.
        // Get a list of recognitions from TFOD.
        recognitions = tfodUltimateGoal.getRecognitions();
        // If list is empty, inform the user. Otherwise, go
        // through list and display info for each recognition.
        if (recognitions.size() == 0) {
          telemetry.addData("TFOD", "No items detected.");
          telemetry.addData("Target Zone", "A");
          left_drive.setPower(-0.75);
          right_drive.setPower(0.75);
          sleep(500);
          left_drive.setPower(-1);
          right_drive.setPower(0.25);
          sleep(800);
          left_drive.setPower(-1);
          right_drive.setPower(0);
          sleep(300);
          left_drive.setPower(0);
          right_drive.setPower(0);
          Arm.setPower(0.75);
          sleep(950);
          Arm.setPower(0);
          sleep(200);
          Gripper.setPosition(1);
          sleep(800);
          // 1ST GOAL DELIVERED
          left_drive.setPower(-0.25);
          right_drive.setPower(-0.75);
          sleep(1200);
          left_drive.setPower(-0.75);
          right_drive.setPower(-0.25);
          sleep(1100);
          left_drive.setPower(0);
          right_drive.setPower(0);
          // SHOOTING RINGS
          left_shooter.setPower(0.7);
          sleep(2000);
          Conveyer.setPower(-0.6);
          sleep(400);
          intake.setPower(1);
          sleep(2000);
          left_shooter.setPower(0);
          Conveyer.setPower(0);
          intake.setPower(0);
          sleep(200);
          left_drive.setPower(-1);
          right_drive.setPower(0.2);
          sleep(1100);
          left_drive.setPower(0);
          right_drive.setPower(0);
          sleep(200);
          Gripper.setPosition(0.5);
          sleep(600);
          Arm.setPower(-0.75);
          sleep(900);
          Arm.setPower(0);
          sleep(200);
          // 2nd GOAL PICKED UP
          left_drive.setPower(0.25);
          right_drive.setPower(-0.25);
          sleep(400);
          left_drive.setPower(-0.25);
          right_drive.setPower(-0.75);
          sleep(1200);
          left_drive.setPower(-0.75);
          right_drive.setPower(-0.25);
          sleep(1300);
          left_drive.setPower(-0.75);
          right_drive.setPower(0.75);
          sleep(800);
          left_drive.setPower(0);
          right_drive.setPower(0);
          sleep(600);
          Arm.setPower(0.75);
          sleep(900);
          Arm.setPower(0);
          sleep(200);
          Gripper.setPosition(1);
          sleep(30000);
        } else {
          index = 0;
          // Iterate through list and call a function to
          // display info for each recognized object.
          for (Recognition recognition_item : recognitions) {
            recognition = recognition_item;
            // Display info.
            displayInfo(index);
            // Increment index.
            index = index + 1;
          }
        }
        telemetry.update();
      }
    }
    // Deactivate TFOD.
    tfodUltimateGoal.deactivate();

    vuforiaUltimateGoal.close();
    tfodUltimateGoal.close();
  }

  /**
   * Display info (using telemetry) for a recognized object.
   */
  private void displayInfo(double i) {
    // Display label info.
    // Display the label and index number for the recognition.
    telemetry.addData("label " + i, recognition.getLabel());
    // Display upper corner info.
    // Display the location of the top left corner
    // of the detection boundary for the recognition
    telemetry.addData("Left, Top " + i, recognition.getLeft() + ", " + recognition.getTop());
    // Display lower corner info.
    // Display the location of the bottom right corner
    // of the detection boundary for the recognition
    telemetry.addData("Right, Bottom " + i, recognition.getRight() + ", " + recognition.getBottom());
    // Display Target Zone
    if (recognition.getLabel().equals("Single")) {
      telemetry.addData("Target Zone", "B");
      left_drive.setPower(-0.7);
      right_drive.setPower(0.8);
      sleep(400);
      left_drive.setPower(0);
      right_drive.setPower(0);
      intake.setPower(1);
      sleep(400);
      left_drive.setPower(-0.6);
      right_drive.setPower(0.4);
      sleep(400);
      left_drive.setPower(-0.75);
      right_drive.setPower(0.75);
      sleep(1400);
      intake.setPower(0);
      left_drive.setPower(0);
      right_drive.setPower(0);
      Arm.setPower(0.75);
      sleep(1000);
      Arm.setPower(0);
      sleep(500);
      Gripper.setPosition(1);
      sleep(200);
      // 1ST GOAL DELIVERED
      left_drive.setPower(0.25);
      right_drive.setPower(-0.25);
      sleep(400);
      left_drive.setPower(-0.25);
      right_drive.setPower(-0.75);
      sleep(1200);
      left_drive.setPower(-1);
      right_drive.setPower(-0.25);
      sleep(850);
      left_drive.setPower(-0.75);
      right_drive.setPower(0.75);
      sleep(1100);
      left_drive.setPower(0);
      right_drive.setPower(0);
      sleep(200);
      Gripper.setPosition(0.5);
      sleep(600);
      Arm.setPower(-0.75);
      sleep(900);
      Arm.setPower(0);
      sleep(200);
      // 2nd GOAL PICKED UP
      left_drive.setPower(1);
      right_drive.setPower(-0.6);
      sleep(600);
      left_drive.setPower(0);
      right_drive.setPower(0);
      sleep(100);
      // SHOOTING RINGS
      left_shooter.setPower(0.7);
      sleep(2000);
      Conveyer.setPower(-0.6);
      sleep(400);
      intake.setPower(1);
      sleep(2000);
      left_shooter.setPower(0);
      Conveyer.setPower(0);
      intake.setPower(0);
      sleep(200);
      // DROPPING THE 2ND WOBBLE GOAL
      left_drive.setPower(1);
      right_drive.setPower(0.25);
      sleep(700);
      left_drive.setPower(0.25);
      right_drive.setPower(0.75);
      sleep(900);
      left_drive.setPower(-0.5);
      right_drive.setPower(0.5);
      sleep(400);
      left_drive.setPower(0);
      right_drive.setPower(0);
      sleep(200);
      Arm.setPower(0.75);
      sleep(900);
      Arm.setPower(0);
      sleep(500);
      Gripper.setPosition(1);
      sleep(30000);
    } else if (recognition.getLabel().equals("Quad")) {
      telemetry.addData("Target Zone", "C");
      left_drive.setPower(-1);
      right_drive.setPower(0.25);
      sleep(700);
      left_drive.setPower(-0.25);
      right_drive.setPower(1);
      sleep(600);
      left_drive.setPower(-1);
      right_drive.setPower(0.8);
      sleep(1400);
      left_drive.setPower(0);
      right_drive.setPower(0);
      Arm.setPower(0.75);
      sleep(1000);
      Arm.setPower(0);
      sleep(500);
      Gripper.setPosition(1);
      sleep(500);
      // 1ST WOBBLE GOAL DROPPED
      left_drive.setPower(0.25);
      right_drive.setPower(-0.25);
      sleep(800);
      left_drive.setPower(-0.25);
      right_drive.setPower(-0.75);
      sleep(1200);
      left_drive.setPower(-1);
      right_drive.setPower(-0.25);
      sleep(900);
      left_drive.setPower(-0.75);
      right_drive.setPower(0.75);
      sleep(800);
      left_drive.setPower(0.75);
      right_drive.setPower(0.25);
      sleep(100);
      left_drive.setPower(0);
      right_drive.setPower(0);
      sleep(200);
      // SHOOTING RINGS
      left_shooter.setPower(0.8);
      sleep(2000);
      Conveyer.setPower(-0.6);
      sleep(400);
      intake.setPower(1);
      sleep(2000);
      left_shooter.setPower(0);
      Conveyer.setPower(0);
      intake.setPower(0);
      sleep(200);
      left_drive.setPower(0.5);
      right_drive.setPower(-0.5);
      sleep(400);
      left_drive.setPower(0);
      right_drive.setPower(0);
      sleep(30000);
    } else {
      telemetry.addData("Target Zone", "UNKNOWN");
    }
  }
}
